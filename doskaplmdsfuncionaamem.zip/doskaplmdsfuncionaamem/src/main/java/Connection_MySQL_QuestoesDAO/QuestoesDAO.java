package Connection_MySQL_QuestoesDAO;

import Connection_MySQL.ConnectionFactory;
import Connection_Questoes.Questoes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class QuestoesDAO {
    public void cadastrar(Questoes p) throws Exception{
    Connection conn = ConnectionFactory.getConnection();  
    PreparedStatement ps = null;
    String sql = "insert into Questoes (Id, Alternativa A, Alternativa B, Alternativa C, Alternativa D, Perguntas, Respostas) values (? ,?, ?,?, ?, ?, ?)";
    try{
        ps = conn.prepareStatement(sql);
        ps.setInt(1, p.getId());
        ps.setString(2, p.getAlternativaA());
        ps.setString(3, p.getAlternativaB());
        ps.setString(4, p.getAlternativaC());
        ps.setString(5,p.getAlternativaD());
        ps.setString(6, p.getPerguntas());
        ps.setString(7, p.getRespostas());
        
        ps.executeUpdate();
        JOptionPane.showMessageDialog(null, "Questões foram inseridas com sucesso");

    }catch(SQLException e){
        JOptionPane.showMessageDialog(null, "Erro ao salvar questões" + e.toString());
    }    
    }
    
    public void atualizar(Questoes p) throws Exception{
        String sql = "upadate Respostas set Alternativa A=?,Alternativa B, Alternativa C, Alternativa D, Perguntas, Respostas=? where Id=?";
    try(var conn = ConnectionFactory.getConnection();   
            var ps = conn.prepareStatement(sql)) {
        ps.setInt(1, p.getId());
        ps.setString(2, p.getAlternativaA());
        ps.setString(3, p.getAlternativaB());
        ps.setString(4, p.getAlternativaC());
        ps.setString(5,p.getAlternativaD());
        ps.setString(6, p.getPerguntas());
        ps.setString(7, p.getRespostas());
        
         ps.executeUpdate();
         JOptionPane.showMessageDialog(null, "Questões atualizads com sucesso");
    } catch(SQLException e){
        JOptionPane.showMessageDialog(null, "Erro ao atualizar questões" + e.toString());
    }
    }    
    
    public void remover(Questoes p) throws Exception{
        String sql = "delete from Respostas where Id=?";
    try(var conn = ConnectionFactory.getConnection();   
            var ps = conn.prepareStatement(sql)) {
        ps.setInt(1, p.getId());
        
         ps.executeUpdate();
         JOptionPane.showMessageDialog(null, "Questões foram removidos com sucesso");
    } catch(SQLException e){
        JOptionPane.showMessageDialog(null, "Erro ao remover os questões" + e.toString());
    }
    }    
    
    public String listar () throws Exception {
        String sql = "select * from Questões";
    try(var conn = ConnectionFactory.getConnection();   
            var ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()){
        StringBuilder sb = new StringBuilder("");
        
        while(rs.next()){
            int id = rs.getInt("Id");
            String AlternativaA = rs.getString("Alternativa A");
            String AlternativaB = rs.getString("Alternativa A");
            String AlternativaC = rs.getString("Alternativa A");
            String AlternativaD = rs.getString("Alternativa A");
            String perguntas = rs.getString("Alternativa A");
            String respostas = rs.getString("Alternativa A");
            
            sb.append(
                 String.format(
                            "Id:%d, Alternativa A:%s, Alternativa B:%s, Alternativa C:%s, Alternativa D:%s, Perguntas:%s, Respostas:%s",
                          id, AlternativaA, AlternativaB, AlternativaC, AlternativaD, perguntas, respostas
                    )
                ).append("\n");
        }
            return sb.toString();
        }       
    }
    
     public String gabarito () throws Exception {
        String sql = "select id, perguntas, respostas from Questoes";
    try(var conn = ConnectionFactory.getConnection();   
            var ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()){
        StringBuilder sb = new StringBuilder("");
        
        while(rs.next()){
            int id = rs.getInt("Id");
            String perguntas = rs.getString("Perguntas");
            String respostas = rs.getString("Respostas");
            
            sb.append(
                 String.format(
                            "Id:%d, Perguntas:%s, Respostas:%s",
                          id, perguntas, respostas
                    )
                ).append("\n");
        }
            return sb.toString();
        }       
    }
}
