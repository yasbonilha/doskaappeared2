/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Jogo;

/**
 *
 * @author felip
 */
public class Dado {
    private int numeroDado;

public void gerarNumero(){
    
}
    
    
}
